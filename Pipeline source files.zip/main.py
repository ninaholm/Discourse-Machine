# -*- coding: utf-8 -*-

from PipelineHandler.PipelineHandler import PipelineHandler
import pyximport; pyximport.install()
import time
import os
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

starttime = time.time()

corpora = [["indland.in", "udland.in", "debat.in", "kultur.in"]]
corpora = [["udland.in"]]

print
print "################# RUNNING SENTIMENT ANALYSIS #################"
print
posc = PipelineHandler(corpora)
posc.run()


print "Total time elapsed: %s seconds" % round((time.time() - starttime), 3)
print

