#ifndef SST_H
#define SST_H

#include "registry.h"
#include "defines.h"
#if STREAM
# include <iostream>
# ifndef __BORLANDC__
using namespace std;
# endif
#else
#include <stdio.h>
#endif


//int start_state_tagger(Registry lexicon_hash,const char * Corpus,const char * Bigrams,const char * Lexicalrulefile,const char * Wordlist,int Corpussize,char *** Word_corpus_array, char *** Tag_corpus_array);
int start_state_tagger
        (
        Registry lexicon_hash,
        Registry bigram_hash,
        Registry wordlist_hash,
#if STREAM
        istream & corpus,
#else
        FILE * corpus,
#endif
        const char * Wordlist,
        int Corpussize,
        char *** Word_corpus_array, 
        char *** Tag_corpus_array,
        Darray rule_array
        );

#endif
