/*  Copyright @ 1993 MIT and University of Pennsylvania*/
/* Written by Eric Brill */
/*THIS SOFTWARE IS PROVIDED "AS IS", AND M.I.T. MAKES NO REPRESENTATIONS 
OR WARRANTIES, EXPRESS OR IMPLIED.  By way of example, but not 
limitation, M.I.T. MAKES NO REPRESENTATIONS OR WARRANTIES OF 
MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF 
THE LICENSED SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY 
PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.   */


#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <malloc.h>
#include <stdlib.h> /* Bart Jongejan 20010220, strtol */
#include <ctype.h> /* Bart Jongejan 20010220, isupper */
#include <locale.h> /* Bart Jongejan 20010220, setlocale */
#include "darray.h"
#include "lex.h"
#include "memory.h"
#include "useful.h"
#include "sst.h"
#include "staart.h"
#include "defines.h"
//#include "log.h"
//LOGCODE

//#define MAXTAGLEN 256  /* max char length of pos tags */
//#define MAXWORDLEN 256 /* max char length of words */
//#define MAXAFFIXLEN 5  /* max length of affixes being considered */

/* Bart Jongejan 20010216 
Convert the first character of the argument to lower case.
*/
char * uncapitalize(char * word)
    {
    static char line[5000];
    if(isupper(word[0]))
        {
        char * d, * s;
        for(d = line,s = word;*s;++d,++s)
            *d = tolower(*s);
        *d = '\0';
        return line;
        }
    else
        return word;
    }


int CheckLineForCapitalizedWordsOrNonAlphabeticStuff(char ** w)
    {
    int tot = 0;
    int low = 0;
    while(*w)
        {
        ++tot;
        if(islower(**w))
            ++low;
        ++w;
        }
    return 2*low < tot; /* return 1 if not heading (less than half of all words begin with lower case.)*/
    }

int start_state_tagger
        (
        Registry lexicon_hash,
        Registry bigram_hash,
        Registry wordlist_hash,
#if STREAM
        istream & corpus,
#else
        FILE * corpus,
#endif
        const char * Wordlist,
        int Corpussize,
        char *** Word_corpus_array, 
        char *** Tag_corpus_array,
        Darray rule_array
        )
    {
    char ** word_corpus_array;
    char ** tag_corpus_array;
    int corpus_array_index = 0;
    char *atempptr;
//    FILE * corpus;
    char line[5000];      /* input line buffer */
    Registry ntot_hash;
    Registry tag_hash;
    Darray tag_array_key,tag_array_val;
    char *tempstr,*tempstr2;
    char **perl_split_ptr,**temp_perl_split_ptr,**therule,**therule2;
    char noun[20] = {'\0'},proper[20] = {'\0'};
    int rulesize,tempcount;
    unsigned int count,count2,count3; /*Bart 20030225*/
    char
        tempstr_space[MAXWORDLEN+MAXAFFIXLEN],bigram_space[MAXWORDLEN*2];
    int EXTRAWDS= 0;
    /* Bart Jongejan 20010216 */
    long ConvertToLowerCaseIfFirstWord = option("ConvertToLowerCaseIfFirstWord");
    long ShowIfLowercaseConversionHelped = option("ShowIfLowercaseConversionHelped");
    long ConvertToLowerCaseIfMostWordsAreCapitalized = option("ConvertToLowerCaseIfMostWordsAreCapitalized");
    long Verbose = option("Verbose"); // Bart 20030224
    char * language = coption("Language");
    char * tmp; // Bart 20030224
    if(language)
        {
        setlocale(LC_CTYPE,language);
        }
        /*
        {
        FILE * fp = fopen("log.txt","a");
        if(fp)
        {
        fprintf(fp,"Locale %s:islower('y') = %d\n",language,islower('y'));
        fprintf(fp,"Locale %s:islower('�') = %d\n",language,islower('�'));
        fprintf(fp,"Locale %s:islower('�') = %d\n",language,islower('�'));
        fprintf(fp,"Locale %s:islower('�') = %d\n",language,islower('�'));
        fprintf(fp,"Locale %s:islower('�') = %d\n",language,islower('�'));
        fprintf(fp,"Locale %s:islower('�') = %d\n",language,islower('�'));
        fclose(fp);
        }
    }*/
    tmp = coption("Noun");
    if(tmp)
        {
        strncpy(noun,tmp,sizeof(noun) - 1);
        noun[sizeof(noun)  - 1] = '\0';
        //                streamout("noun = {%s}",noun);
        }
    tmp = coption("Proper");
    if(tmp)
        {
        strncpy(proper,tmp,sizeof(proper) - 1);
        proper[sizeof(proper)  - 1] = '\0';
        //                streamout("proper = {%s}",proper);
        }
    
    
    /***********************************************************************/
    
    
        /* Wordlist_hash contains a list of words.  This is used 
        for tagging unknown words in the "add prefix/suffix" and
    "delete prefix/suffix" rules.  This contains words not in LEXICON. */
    
    if (Wordlist) 
        {
        EXTRAWDS=1;
        }
    
    /*********************************************************/
    /* Read in corpus to be tagged.  Actually, just record word list, */
    /* since each word will get the same tag, regardless of context. */
    ntot_hash = Registry_create(Registry_strcmp,Registry_strhash);

#if STREAM
    corpus.clear();
    corpus.seekg(0, ios::beg);
#else
    rewind(corpus);
#endif
    
    //corpus = fopen(Corpus,"r");

    *Word_corpus_array = word_corpus_array = (char **)malloc(sizeof(char *) * Corpussize);
    *Tag_corpus_array = tag_corpus_array = (char **)malloc(sizeof(char *) * Corpussize);
    INCREMENT
    INCREMENT

    
#if STREAM
    while(!corpus.eof())
        {
        corpus.getline(line,sizeof(line));
        if (not_just_blank(line))
            {
            int startOfLine = Bool_TRUE; /* Bart Jongejan 20010216 */
            int heading = Bool_FALSE; /* Bart Jongejan 20010220 */
            if(line[strlen(line) - 1] == ' ')
                line[strlen(line) - 1] = '\0';
//            else
//                line[strlen(line)] = '\0';
            perl_split_ptr = perl_split_independent(line);
            temp_perl_split_ptr = perl_split_ptr;
            if(ConvertToLowerCaseIfMostWordsAreCapitalized)
                {
                heading = CheckLineForCapitalizedWordsOrNonAlphabeticStuff(perl_split_ptr);
                }
            while (*temp_perl_split_ptr != NULL) 
                { 
//                LOG("WOORD %s",(char *)*temp_perl_split_ptr);
                if(  Registry_get(lexicon_hash,(char *)*temp_perl_split_ptr) == NULL
                  && (  heading && Registry_get(lexicon_hash,uncapitalize((char *)*temp_perl_split_ptr)) == NULL
                     || !startOfLine
                     || ConvertToLowerCaseIfFirstWord != 1
                     || Registry_get(lexicon_hash,uncapitalize((char *)*temp_perl_split_ptr)) == NULL
                     )
                  ) 
                    {
                    if (!Registry_add(ntot_hash,(char *)*temp_perl_split_ptr,(char *)1)) 
                        {
//                        LOG("WOORD %s not added",(char *)*temp_perl_split_ptr);
                        free(*temp_perl_split_ptr);
                        DECREMENT
                        }
                    }
                else 
                    {
                    free(*temp_perl_split_ptr);
                    DECREMENT
                    }
                ++temp_perl_split_ptr;
                startOfLine = Bool_FALSE;
                }
            free(perl_split_ptr);
            DECREMENT
            }
        }
    corpus.clear();
    corpus.seekg(0, ios::beg);
#else
    while(fgets(line,sizeof(line),corpus) != NULL) 
        {
        if (not_just_blank(line))
            {
            int startOfLine = Bool_TRUE; /* Bart Jongejan 20010216 */
            int heading = Bool_FALSE; /* Bart Jongejan 20010220 */
            line[strlen(line) - 1] = '\0';
            perl_split_ptr = perl_split_independent(line);
            temp_perl_split_ptr = perl_split_ptr;
            if(ConvertToLowerCaseIfMostWordsAreCapitalized)
                {
                heading = CheckLineForCapitalizedWordsOrNonAlphabeticStuff(perl_split_ptr);
                }
            while (*temp_perl_split_ptr != NULL) 
                { 
//                LOG("WOORD %s",(char *)*temp_perl_split_ptr);
                if(  Registry_get(lexicon_hash,(char *)*temp_perl_split_ptr) == NULL
                  && (  heading && Registry_get(lexicon_hash,uncapitalize((char *)*temp_perl_split_ptr)) == NULL
                     || !startOfLine
                     || ConvertToLowerCaseIfFirstWord != 1
                     || Registry_get(lexicon_hash,uncapitalize((char *)*temp_perl_split_ptr)) == NULL
                     )
                  ) 
                    {
                    if (!Registry_add(ntot_hash,(char *)*temp_perl_split_ptr,(char *)1)) 
                        {
//                        LOG("WOORD %s not added",(char *)*temp_perl_split_ptr);
                        free(*temp_perl_split_ptr);
                        DECREMENT
                        }
                    }
                else 
                    {
                    free(*temp_perl_split_ptr);
                    DECREMENT
                    }
                ++temp_perl_split_ptr;
                startOfLine = Bool_FALSE;
                }
            free(perl_split_ptr);
            DECREMENT
            }
        }
    rewind(corpus);
#endif
    
    
    
    if(Verbose) // Bart 20030224
        {
        /*//Bart 20010425*/ 	 fprintf(stderr,"START STATE TAGGER:: CORPUS READ\n");  
        }
    
    
    tag_array_key = Darray_create();
    tag_array_val = Darray_create();
    Registry_fetch_contents(ntot_hash,tag_array_key,tag_array_val);

    Registry_destroy(ntot_hash);


    /********** START STATE ALGORITHM
    YOU CAN USE OR EDIT ONE OF THE TWO START STATE ALGORITHMS BELOW, 
# OR REPLACE THEM WITH YOUR OWN ************************/
    
    if(!*noun) // Bart 20030224
        {
        strcpy(noun,"NN");
        }
    if(!*proper) // Bart 20030224
        {
        strcpy(proper,"NNP");
        }
    
        /* UNCOMMENT THIS AND COMMENT OUT START STATE 2 IF ALL UNKNOWN WORDS
        SHOULD INITIALLY BE ASSUMED TO BE TAGGED WITH "NN".
    YOU CAN ALSO CHANGE "NN" TO A DIFFERENT TAG IF APPROPRIATE. */
    
    /*** START STATE 1 ***/
    /*   for (count= 0; count < Darray_len(tag_array_val);++count) 
    Darray_set(tag_array_val,count,noun); */
    
    /* THIS START STATE ALGORITHM INITIALLY TAGS ALL UNKNOWN WORDS WITH TAG 
    "NN" (singular common noun) UNLESS THEY BEGIN WITH A CAPITAL LETTER, 
    IN WHICH CASE THEY ARE TAGGED WITH "NNP" (singular proper noun)
    YOU CAN CHANGE "NNP" and "NN" TO DIFFERENT TAGS IF APPROPRIATE.*/
    
    /*** START STATE 2 ***/
    
    for (count= 0; count < Darray_len(tag_array_val);++count) 
        {
        if (isUpper((char *)Darray_get(tag_array_key,count)))/*Bart 20030225*/
            {
            /*
            if (((char *)Darray_get(tag_array_key,count))[0] >='A' && 
            ((char *)Darray_get(tag_array_key,count))[0] <= 'Z') */
            Darray_set(tag_array_val,count,proper); 
            }
        else
            {
            Darray_set(tag_array_val,count,noun); 
            }
        }
    
    
    
    /******************* END START STATE ALGORITHM ****************/
    for (count= 0;count < Darray_len(rule_array);++count) 
        {
        //tempstr = (char *)Darray_get(rule_array,count);
        therule = (char **)Darray_get(rule_array,count);
        /*fprintf(stderr,"RULE IS: %s\n",tempstr);*/
        if(Verbose) // Bart 20030224
            /*//Bart 20010425*/ fprintf(stderr,"s");
        //therule = perl_split_independent(tempstr);
            /* we don't worry about freeing "rule" space, as this is a small fraction
            of total memory used */
        therule2 = &therule[1];
        rulesize= 0;
        perl_split_ptr = therule;
        while(*(++perl_split_ptr) != NULL) 
            {
            ++rulesize;
            }
        
        if (strcmp(therule[1],"char") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    if(strpbrk((char *)Darray_get(tag_array_key,count2), therule[0]) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        else if (strcmp(therule2[1],"fchar") == 0) 
            { 
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0) 
                    {
                    if(strpbrk((char *)Darray_get(tag_array_key,count2), therule2[0]) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        else if (strcmp(therule[1],"deletepref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    tempstr = (char *)Darray_get(tag_array_key,count2);
                    for (count3 = 0;(int)/*Bart 20030225*/count3 < atoi(therule[2]);++count3) 
                        {
                        if (tempstr[count3] != therule[0][count3])
                            break;
                        }
                    if ((int)/*Bart 20030225*/count3 == atoi(therule[2])) 
                        {
                        tempstr += atoi(therule[2]);
                        if (  Registry_get(lexicon_hash,(char *)tempstr) != NULL 
                           || (  EXTRAWDS 
                              && Registry_get(wordlist_hash,(char *)tempstr) != NULL
                              )
                           )
                            {
                            Darray_set(tag_array_val,count2,therule[rulesize-1]);
                            }
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fdeletepref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0)
                    { 
                    tempstr=(char *)Darray_get(tag_array_key,count2);
                    for (count3 = 0;(int)/*Bart 20030225*/count3 < atoi(therule2[2]);++count3) 
                        {
                        if (tempstr[count3] != therule2[0][count3])
                            {
                            break;
                            }
                        }
                    if ((int)/*Bart 20030225*/count3 == atoi(therule2[2])) 
                        {
                        tempstr += atoi(therule2[2]);
                        if (  Registry_get(lexicon_hash,(char *)tempstr) != NULL 
                           || (  EXTRAWDS 
                              && Registry_get(wordlist_hash,(char *)tempstr) != NULL
                              )
                           )
                            {
                            Darray_set(tag_array_val,count2,therule[rulesize-1]);
                            }
                        }
                    }
                }
            }
        
        
        else if (strcmp(therule[1],"haspref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    tempstr = (char *)Darray_get(tag_array_key,count2);
                    for (count3 = 0;(int)/*Bart 20030225*/count3 < atoi(therule[2]);++count3) 
                        {
                        if (tempstr[count3] != therule[0][count3])
                            {
                            break;
                            }
                        }
                    if ((int)/*Bart 20030225*/count3 == atoi(therule[2])) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fhaspref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0)
                    { 
                    tempstr=(char *)Darray_get(tag_array_key,count2);
                    for (count3 = 0;(int)/*Bart 20030225*/count3 < atoi(therule2[2]);++count3) 
                        {
                        if (tempstr[count3] != therule2[0][count3])
                            {
                            break;
                            }
                        }
                    if ((int)/*Bart 20030225*/count3 == atoi(therule2[2])) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        
        else if (strcmp(therule[1],"deletesuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    tempstr = (char *)Darray_get(tag_array_key,count2);
                    tempcount=strlen(tempstr) - atoi(therule[2]);
                    for (count3 = tempcount;count3 < strlen(tempstr); ++count3) 
                        {
                        if (tempstr[count3] != therule[0][count3-tempcount])
                            {
                            break;
                            }
                        }
                    if (count3 == strlen(tempstr)) 
                        {
                        tempstr2 = mystrdup(tempstr);
                        tempstr2[tempcount] = '\0';
                        if (  Registry_get(lexicon_hash,(char *)tempstr2) != NULL 
                           || (  EXTRAWDS 
                              && Registry_get(wordlist_hash,(char *)tempstr2) != NULL
                              )
                           ) 
                            {
                            Darray_set(tag_array_val,count2,therule[rulesize-1]);
                            }
                        free(tempstr2);
                        DECREMENT
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fdeletesuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0)
                    { 
                    tempstr=(char *)Darray_get(tag_array_key,count2);
                    tempcount=strlen(tempstr) - atoi(therule2[2]);
                    for (count3 = tempcount;count3 < strlen(tempstr); ++count3) 
                        {
                        if (tempstr[count3] != therule2[0][count3-tempcount])
                            {
                            break;
                            }
                        }
                    if (count3 == strlen(tempstr))
                        {
                        tempstr2 = mystrdup(tempstr);
                        tempstr2[tempcount] = '\0';
                        if (  Registry_get(lexicon_hash,(char *)tempstr2) != NULL
                           || (  EXTRAWDS 
                              && Registry_get(wordlist_hash,(char *)tempstr2) != NULL
                              )
                           ) 
                            {
                            Darray_set(tag_array_val,count2,therule[rulesize-1]);
                            }
                        free(tempstr2);
                        DECREMENT
                        }
                    }
                }
            }
        else if (strcmp(therule[1],"hassuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    tempstr = (char *)Darray_get(tag_array_key,count2);
                    tempcount=strlen(tempstr) - atoi(therule[2]);
                    for (count3 = tempcount;count3 < strlen(tempstr); ++count3) 
                        {
                        if (tempstr[count3] != therule[0][count3-tempcount])
                            {
                            break;
                            }
                        }
                    if (count3 == strlen(tempstr)) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fhassuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0)
                    { 
                    tempstr = (char *)Darray_get(tag_array_key,count2);
                    tempcount = strlen(tempstr) - atoi(therule2[2]);
                    for (count3 = tempcount;count3 < strlen(tempstr); ++count3) 
                        {
                        if (tempstr[count3] != therule2[0][count3-tempcount])
                            {
                            break;
                            }
                        }
                    if (count3 == strlen(tempstr))
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule[1],"addpref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) == 0)
                    {
                    sprintf(tempstr_space,"%s%s",therule[0],(char *)Darray_get(tag_array_key,count2));
                    if (  Registry_get(lexicon_hash,(char *)tempstr_space) != NULL
                       || (  EXTRAWDS 
                          && Registry_get(wordlist_hash,(char *)tempstr_space) != NULL
                          )
                       ) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"faddpref") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) == 0)
                    {
                    sprintf(tempstr_space,"%s%s",therule2[0],(char *)Darray_get(tag_array_key,count2));
                    if (  Registry_get(lexicon_hash,(char *)tempstr_space) != NULL
                       || (  EXTRAWDS 
                          && Registry_get(wordlist_hash,(char *)tempstr_space) != NULL
                          )
                       ) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        
        else if (strcmp(therule[1],"addsuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    sprintf(tempstr_space,"%s%s", (char *)Darray_get(tag_array_key,count2), therule[0]);
                    if (  Registry_get(lexicon_hash,(char *)tempstr_space) != NULL
                       || (  EXTRAWDS 
                          && Registry_get(wordlist_hash,(char *)tempstr_space) != NULL
                          )
                       )
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        
        else if (strcmp(therule2[1],"faddsuf") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0) 
                    {
                    sprintf(tempstr_space,"%s%s", (char *)Darray_get(tag_array_key,count2), therule2[0]);
                    if (  Registry_get(lexicon_hash,(char *)tempstr_space) != NULL
                       || (  EXTRAWDS 
                          && Registry_get(wordlist_hash,(char *)tempstr_space) != NULL
                          )
                       )
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        
        else if (strcmp(therule[1],"goodleft") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    sprintf(bigram_space,"%s %s", (char *)Darray_get(tag_array_key,count2),therule[0]);
                    if (Registry_get(bigram_hash,(char *)bigram_space) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fgoodleft") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0) 
                    {
                    sprintf(bigram_space,"%s %s",(char *)Darray_get(tag_array_key,count2),therule2[0]);
                    if (Registry_get(bigram_hash,(char *)bigram_space) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule[1],"goodright") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[rulesize-1]) != 0) 
                    {
                    sprintf(bigram_space,"%s %s",therule[0],(char *)Darray_get(tag_array_key,count2));
                    if (Registry_get(bigram_hash,(char *)bigram_space) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        else if (strcmp(therule2[1],"fgoodright") == 0) 
            {
            for (count2 = 0;count2 < Darray_len(tag_array_key);++count2) 
                {
                if (strcmp((char *)Darray_get(tag_array_val,count2),therule[0]) == 0) 
                    {
                    sprintf(bigram_space,"%s %s",therule2[0],(char *)Darray_get(tag_array_key,count2));
                    if (Registry_get(bigram_hash,(char *)bigram_space) != NULL) 
                        {
                        Darray_set(tag_array_val,count2,therule[rulesize-1]);
                        }
                    }
                }
            }
        
        
        }
    if(Verbose) // Bart 20030224
        {
        /*//Bart 20010425*/ 	fprintf(stderr,"\n");
        }
    
    
    /* now go from darray to hash table */
    
    tag_hash = Registry_create(Registry_strcmp,Registry_strhash);
    for (count= 0;count < Darray_len(tag_array_key);++count) 
        {
        char * name = (char *)Darray_get(tag_array_key,count);
        char * val = (char *)Darray_get(tag_array_val,count);
        if(!Registry_add(tag_hash, name, val))
            {
            if(name)
                {
                free(name);
                DECREMENT
                }
/*            if(val)
                {
                free(val);
                allocated -= 1;
                } These are NOT allocated separately */
            }
        }

    Darray_destroy(tag_array_key);
    Darray_destroy(tag_array_val);


//    corpus = fopen(Corpus,"r");


#if STREAM
    while(!corpus.eof())
        {
        corpus.getline(line,sizeof(line));
        if (not_just_blank(line)) 
            {
            int startOfLine = Bool_TRUE; /* Bart Jongejan 20010216 */
            int heading = Bool_FALSE; /* Bart Jongejan 20010220 */
            if(line[strlen(line) - 1] == ' ')
                line[strlen(line) - 1] = '\0';
            perl_split_ptr = perl_split(line);
            temp_perl_split_ptr = perl_split_ptr;
            if(ConvertToLowerCaseIfMostWordsAreCapitalized)
                {
                heading = CheckLineForCapitalizedWordsOrNonAlphabeticStuff(perl_split_ptr);
                }

            word_corpus_array[corpus_array_index] = staart;
            tag_corpus_array[corpus_array_index++] = staart;
            word_corpus_array[corpus_array_index] = staart;
            tag_corpus_array[corpus_array_index++] = staart;

/*            
            word_corpus_array[corpus_array_index] = mystrdup(*split_ptr);
            tag_corpus_array[corpus_array_index++] = mystrdup(atempstrptr);
*/

            while (*temp_perl_split_ptr != NULL) 
                {
                int second = Bool_FALSE;
                if (  (atempptr = strchr(*temp_perl_split_ptr,'/')) != NULL
                   && *(atempptr+1) == '/'
                   ) 
                    {
                    /* a word can be pretagged by putting two slashes between the */
                    /* word and the tag ::  The boy//NN ate . */
                    /* if a word is pretagged, we just spit out the pretagging */
                    *atempptr = '\0';
                    word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                    tag_corpus_array[corpus_array_index++] = mystrdup(atempptr+2); // Skip the second slash. This is different from the old behaviour. Bart 20040129
                    }
                else if(  (tempstr = (char *)Registry_get(lexicon_hash,*temp_perl_split_ptr))!= NULL
                       || (  heading 
                          && ( second = Bool_TRUE
                             ,  (tempstr = (char *)Registry_get(lexicon_hash,uncapitalize(*temp_perl_split_ptr))) != NULL
                             )
                          )
                       || (  startOfLine
                          && ConvertToLowerCaseIfFirstWord == 1
                          && (  second = Bool_TRUE
                             ,  (tempstr = (char *)Registry_get(lexicon_hash,uncapitalize(*temp_perl_split_ptr))) != NULL
                             )
                          )
                       )
                    {
                    if(ShowIfLowercaseConversionHelped && second)
                        {
                        char buffer[256];
                        if(heading)
                            {
                            sprintf(buffer,"(head)(low)%s",*temp_perl_split_ptr);
                            }
                        else
                            {
                            sprintf(buffer,"(low)%s",*temp_perl_split_ptr);
                            }
                        word_corpus_array[corpus_array_index] = mystrdup(buffer);
                        }
                    else
                        {
                        word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                        }
                    tag_corpus_array[corpus_array_index++] = mystrdup(tempstr);
                    }
                else 
                    {
                    word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                    tag_corpus_array[corpus_array_index++] = mystrdup((char *)Registry_get(tag_hash,*temp_perl_split_ptr));
                    }
                ++temp_perl_split_ptr;
                startOfLine = Bool_FALSE;
                }
            free(*perl_split_ptr);
            free(perl_split_ptr);
            DECREMENT
            DECREMENT
            }
        }
    corpus.clear();
    corpus.seekg(0, ios::beg);
#else
    while(fgets(line,sizeof(line),corpus) != NULL) 
        {
        if (not_just_blank(line)) 
            {
            int startOfLine = Bool_TRUE; /* Bart Jongejan 20010216 */
            int heading = Bool_FALSE; /* Bart Jongejan 20010220 */
            line[strlen(line) - 1] = '\0';
            perl_split_ptr = perl_split(line);
            temp_perl_split_ptr = perl_split_ptr;
            if(ConvertToLowerCaseIfMostWordsAreCapitalized)
                {
                heading = CheckLineForCapitalizedWordsOrNonAlphabeticStuff(perl_split_ptr);
                }

            word_corpus_array[corpus_array_index] = staart;
            tag_corpus_array[corpus_array_index++] = staart;
            word_corpus_array[corpus_array_index] = staart;
            tag_corpus_array[corpus_array_index++] = staart;

/*            
            word_corpus_array[corpus_array_index] = mystrdup(*split_ptr);
            tag_corpus_array[corpus_array_index++] = mystrdup(atempstrptr);
*/

            while (*temp_perl_split_ptr != NULL) 
                {
                int second = Bool_FALSE;
                if (  (atempptr = strchr(*temp_perl_split_ptr,'/')) != NULL
                   && *(atempptr+1) == '/'
                   ) 
                    {
                    /* a word can be pretagged by putting two slashes between the */
                    /* word and the tag ::  The boy//NN ate . */
                    /* if a word is pretagged, we just spit out the pretagging */
                    *atempptr = '\0';
                    word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                    tag_corpus_array[corpus_array_index++] = mystrdup(atempptr+2); // Skip the second slash. This is different from the old behaviour. Bart 20040129
                    }
                else if(  (tempstr = (char *)Registry_get(lexicon_hash,*temp_perl_split_ptr))!= NULL
                       || (  heading 
                          && ( second = Bool_TRUE
                             ,  (tempstr = (char *)Registry_get(lexicon_hash,uncapitalize(*temp_perl_split_ptr))) != NULL
                             )
                          )
                       || (  startOfLine
                          && ConvertToLowerCaseIfFirstWord == 1
                          && (  second = Bool_TRUE
                             ,  (tempstr = (char *)Registry_get(lexicon_hash,uncapitalize(*temp_perl_split_ptr))) != NULL
                             )
                          )
                       )
                    {
                    if(ShowIfLowercaseConversionHelped && second)
                        {
                        char buffer[256];
                        if(heading)
                            {
                            sprintf(buffer,"(head)(low)%s",*temp_perl_split_ptr);
                            }
                        else
                            {
                            sprintf(buffer,"(low)%s",*temp_perl_split_ptr);
                            }
                        word_corpus_array[corpus_array_index] = mystrdup(buffer);
                        }
                    else
                        {
                        word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                        }
                    tag_corpus_array[corpus_array_index++] = mystrdup(tempstr);
                    }
                else 
                    {
                    word_corpus_array[corpus_array_index] = mystrdup(*temp_perl_split_ptr);
                    tag_corpus_array[corpus_array_index++] = mystrdup((char *)Registry_get(tag_hash,*temp_perl_split_ptr));
                    }
                ++temp_perl_split_ptr;
                startOfLine = Bool_FALSE;
                }
            free(*perl_split_ptr);
            free(perl_split_ptr);
            DECREMENT
            DECREMENT
            }
        }
    rewind(corpus);
#endif

    freeRegistryOnlyNames(tag_hash);
    return corpus_array_index;
    }


