#include "tagger.h"
#if STREAM
# include <fstream>
# if defined __BORLANDC__
#  include <strstrea.h>
# else
#  ifdef __GNUG__
#   if __GNUG__ > 2
#    include <sstream>
#   else
#    include <strstream.h>
#   endif
#  else
#   include <sstream>
#  endif
# endif
# ifndef __BORLANDC__
using namespace std;
# endif
#endif
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
//#include "log.h"
//LOGCODE
#include "useful.h" // mystrdup

#if defined __MSDOS__ || defined _WIN32			//if PC version
#include <io.h>
int getopt(int argc,char *argv[],char *opts);
#else
#include <unistd.h>
#endif





extern char *optargCST;
extern int optindCST;

int main(int argc, char **argv)
    {
    int START_ONLY_FLAG,FINAL_ONLY_FLAG;
    char ** tempargv = NULL;
    int tempargc;
    int c;
    char * wdlistname = NULL; 
    char * intermed = NULL;
    int splitnum = 0;
    const char * Lexicon = NULL;
    const char * Corpus = NULL;
    const char * Bigrams = NULL;
    const char * Lexicalrulefile = NULL;
    const char * Contextualrulefile = NULL;

//    LOG(NULL);
#if 0 // Bart 20040514
#if defined __MSDOS__ || defined _WIN32			//if PC version
#ifdef __BORLANDC__
#define _access access
#endif
    if(_access(START_PROG,0) != 0)
        {
        switch(errno)
            {
            case EACCES: printf("%s: EACCES\n",START_PROG);break;
            case ENOENT: printf("%s: ENOENT\n",START_PROG);break;
            }
        }
    
    if(_access(END_PROG,0) != 0)
        {
        switch(errno)
            {
            case EACCES: printf("%s: EACCES\n",END_PROG);break;
            case ENOENT: printf("%s: ENOENT\n",END_PROG);break;
            }
        }
    if (_access(START_PROG,0) != 0 ||//Bart 20010104
        _access(END_PROG,0) != 0) 
        {//Bart 20010104
        fprintf(stderr,"YOU MUST RUN THIS PROGRAM IN THE SAME DIRECTORY AS %s and %s\n",
            START_PROG,END_PROG);
        fprintf(stderr,"AND %s and %s MUST HAVE EXECUTE PERMISSION SET\n",START_PROG,
            END_PROG);
        exit(0);
        }
#else
    if (access(START_PROG,X_OK) != 0 ||
        access(END_PROG,X_OK) != 0) 
        {
        fprintf(stderr,"YOU MUST RUN THIS PROGRAM IN THE SAME DIRECTORY AS %s and %s\n",
            START_PROG,END_PROG);
        fprintf(stderr,"AND %s and %s MUST HAVE EXECUTE PERMISSION SET\n",START_PROG,
            END_PROG);
        exit(0);
        }
#endif
#endif    
    
    START_ONLY_FLAG = 0;
    FINAL_ONLY_FLAG = 0;
    
    
    tempargc = 1;
    tempargv = argv;
    ++tempargv;
    while(tempargc < argc && *tempargv[0] != '-') 
        {
        ++tempargc;
        ++tempargv;
        }
    if (tempargc < argc && *tempargv[0] == '-' && argc!= 2 && tempargc<5) 
        {
        fprintf(stderr,"ARGUMENTS MUST COME BEFORE OPTIONS\n");
        exit(0);
        }
    if (tempargc < argc && *tempargv[0] == '-') 
        {
        tempargv--;
        tempargc = argc - tempargc + 1; 
        }
    else 
        {
        tempargc = argc;
        tempargv = argv;
        }
    while( (c = getopt(tempargc, tempargv, "s:w:i:SFh")) != -1) 
        {
        switch (c) 
            {
            case 'w': 
                wdlistname = mystrdup(optargCST);
#if defined __MSDOS__ || defined _WIN32			//if PC version
                if (_access(wdlistname,4) != 0) 
                    {      //Bart 20010104
                    fprintf(stderr,"COULD NOT OPEN %s\n",wdlistname);
                    exit(0);
                    }
#else
                if (access(wdlistname,R_OK) != 0) 
                    {
                    fprintf(stderr,"COULD NOT OPEN %s\n",wdlistname);
                    exit(0);
                    }
#endif
                break;
            case 'i':
                intermed = mystrdup(optargCST);
                break;
            case 's':
                splitnum = atoi(optargCST);
                if (splitnum < 100) 
                    {
                    fprintf(stderr,"TOO SMALL A NUMBER TO SPLIT ON.  WILL NOT BE EFFICIENT\n");
                    exit(0);
                    }
                break;
            case 'S':
                START_ONLY_FLAG = 1;
                break;
            case 'F':
                FINAL_ONLY_FLAG = 1;
                break;
            case 'h':
            case '?':
                printf("usage: %s LEXICON CORPUS-TO-TAG BIGRAMS LEXICALRULEFILE CONTEXTUALRULEFILE [-w WORDLIST] [-s SPLITNUMBER] [-i INTERMEDFILE] -S -F \n",argv[0]);
                exit(0);
                break;
            }
        }
        
    int temp = (2*(splitnum ? 1 : 0) + 2*(wdlistname ? 1 : 0) +2*(intermed ? 1 : 0) + FINAL_ONLY_FLAG + START_ONLY_FLAG);
    if (argc < (6 + temp)) 
        {
        fprintf(stderr,"TOO FEW ARGUMENTS\n");
        exit(0);
        }
    if (argc > (6 + temp)) 
        {
        fprintf(stderr,"TOO MANY ARGUMENTS\n");
        exit(0);
        }
    for(int count = 1;count < argc - temp;++count) 
        {
#if defined __MSDOS__ || defined _WIN32			//if PC version
        if (_access(argv[count],4) != 0) 
            {
            fprintf(stderr,"COULD NOT OPEN %s\n",argv[count]);
            exit(0);
            }
#else
        if (access(argv[count],R_OK) != 0) 
            {
            fprintf(stderr,"COULD NOT OPEN %s\n",argv[count]);
            exit(0);
            }
#endif
        }

    Lexicon = argv[1];
    Corpus = argv[2];
    Bigrams = argv[3];
    Lexicalrulefile = argv[4];
    Contextualrulefile = argv[5];
    
    
    
    tagger theTagger;

    if(!theTagger.init  (Lexicon
                        ,Bigrams
                        ,Lexicalrulefile
                        ,Contextualrulefile
                        ,intermed           // i
                        ,wdlistname         // w
                        ,splitnum           // s
                        ,START_ONLY_FLAG    // S
                        ,FINAL_ONLY_FLAG    // F
                        )
      )
        return 1;


#if !STREAM
    FILE * out = stdout;//fopen("output.txt","wb");
    FILE * corpus = fopen(Corpus,"rb");
    theTagger.analyse(corpus,out);
#else
    ifstream instream(Corpus);
    while(true)
        {
        char line[2048];

        instream/*cin*/.getline(line,sizeof(line),'\n');
        if(!line[0])
            break;
#if defined __BORLANDC__
        strstream * str = new strstream;
        *str << line;
        strstream str2;
        theTagger.analyse(*str,str2);
#else
#if defined __GNUG__ && __GNUG__ < 3
        std::strstream str;
        str << line;
        strstream str2;
#else
        std::stringstream str;
        str << line;
        stringstream str2;
#endif
        theTagger.analyse(str,str2);
#endif
        str2 << '\0';
#if defined __BORLANDC__ || defined __GNUG__ && __GNUG__ < 3
        if(str2.str())
#endif
            cout << str2.str();
//        delete str;
        }
#endif
    
#if !STREAM
    if(out != stdout)
        fclose(out);
    fclose(corpus);
#else
#endif
    return 0;
    }


