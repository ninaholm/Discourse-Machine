/* Copyright @ 1993 MIT and University of Pennsylvania */
/* Written by Eric Brill */
/*THIS SOFTWARE IS PROVIDED "AS IS", AND M.I.T. MAKES NO REPRESENTATIONS 
OR WARRANTIES, EXPRESS OR IMPLIED.  By way of example, but not 
limitation, M.I.T. MAKES NO REPRESENTATIONS OR WARRANTIES OF 
MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF 
THE LICENSED SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY 
PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.   */

#include <stdio.h>
#include <fcntl.h>
#include <malloc.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>/* Bart 20001218 atoi */
#include "lex.h"
#include "darray.h"
#include "memory.h"
#include "useful.h"
#include "fst.h"
#include "staart.h"

#define MAXTAGLEN 256  /* max char length of pos tags */
#define MAXWORDLEN 256 /* max char length of words */

			     

char staart[] = "STAART";

void change_the_tag(char **theentry,char *thetag,int theposition)
    {
    free(theentry[theposition]);
    DECREMENT
    theentry[theposition] = mystrdup(thetag);
    }

int final_state_tagger(
#if STREAM
               ostream & fpout,
#else
               FILE * fpout,
#endif
                       const char * Contextualrulefile,int Corpussize,/*int Linenums,int Tagnums,*/char ** word_corpus_array, char ** tag_corpus_array
#if RESTRICT_MOVE
                       , Registry SEENTAGGING, Registry WORDS
#endif
                       )
    {
    if(Corpussize < 0)
        return 1; 
        
//    FILE           *allowedmovefile;
    FILE           *changefile;
    
//    Registry SEENTAGGING,WORDS;
//    char            *atempstrptr;
    char            line[5000];	/* input line buffer */
//    char            space[500];
//    int             linenums,tagnums;
//    char            **word_corpus_array,**tag_corpus_array;
//    int            word_corpus_array_index,tag_corpus_array_index;
    char **split_ptr;
//    char **split_ptr2;
    int    corpus_max_index;
    int             tempcount1,tempcount2;
    int    count;
    char            old[MAXTAGLEN], neww[MAXTAGLEN], when[50],
        tag[MAXTAGLEN], lft[MAXTAGLEN], rght[MAXTAGLEN],
        prev1[MAXTAGLEN], prev2[MAXTAGLEN], next1[MAXTAGLEN],
        next2[MAXTAGLEN], curtag[MAXTAGLEN],
        curwd[MAXWORDLEN],
        tempstr[MAXWORDLEN],word[MAXWORDLEN],/***perl_split_ptr,
        **perl_split_ptr2,*atempstr,*/atempstr2[256];
    long Verbose = option("Verbose"); // Bart 20030224
    char * myline = NULL;
    
//    linenums = Linenums;
//    tagnums = Tagnums;
    if(Verbose) /* Bart 20030224 */
        {
        fprintf(stderr,"FINAL STATE TAGGER:: READ IN OUTPUT FROM START\n");	
        }

    if(Verbose) /* Bart 20030224*/
        {
        fprintf(stderr,"FINAL STATE TAGGER:: READ IN LEXICON\n");
        }
    /* read in rule file, and process each rule */
    changefile = fopen(Contextualrulefile, "r");
    corpus_max_index = Corpussize;//tag_corpus_array_index - 1;
    while (fgets(line, sizeof(line), changefile) != NULL) 
    /*while (fgets(line, linelen, changefile) != NULL) */
        {/* Bart 20030415 */
        if (not_just_blank(line)) 
            {
            line[strlen(line) - 1] = '\0';
            split_ptr = perl_split(line);
            strcpy(old, split_ptr[0]);
            strcpy(neww, split_ptr[1]);
            strcpy(when, split_ptr[2]);
            if(Verbose) // Bart 20030224
                {
                fprintf(stderr,"OLD: %s NEW: %s WHEN: %s\n", old, neww, when);
                }
            if (strcmp(when, "NEXTTAG") == 0 ||
                strcmp(when, "NEXT2TAG") == 0 ||
                strcmp(when, "NEXT1OR2TAG") == 0 ||
                strcmp(when, "NEXT1OR2OR3TAG") == 0 ||
                strcmp(when, "PREVTAG") == 0 ||
                strcmp(when, "PREV2TAG") == 0 ||
                strcmp(when, "PREV1OR2TAG") == 0 ||
                strcmp(when, "PREV1OR2OR3TAG") == 0) 
                {
                strcpy(tag, split_ptr[3]);
                } 
            else if (strcmp(when, "NEXTWD") == 0 ||
                strcmp(when,"CURWD") == 0 ||
                strcmp(when, "NEXT2WD") == 0 ||
                strcmp(when, "NEXT1OR2WD") == 0 ||
                strcmp(when, "NEXT1OR2OR3WD") == 0 ||
                strcmp(when, "PREVWD") == 0 ||
                strcmp(when, "PREV2WD") == 0 ||
                strcmp(when, "PREV1OR2WD") == 0 ||
                strcmp(when, "PREV1OR2OR3WD") == 0) 
                {
                strcpy(word, split_ptr[3]);
                }
            else if (strcmp(when, "SURROUNDTAG") == 0) 
                {
                strcpy(lft, split_ptr[3]);
                strcpy(rght, split_ptr[4]);
                }
            else if (strcmp(when, "PREVBIGRAM") == 0) 
                {
                strcpy(prev1, split_ptr[3]);
                strcpy(prev2, split_ptr[4]);
                } 
            else if (strcmp(when, "NEXTBIGRAM") == 0) 
                {
                strcpy(next1, split_ptr[3]);
                strcpy(next2, split_ptr[4]);
                }
            else if (strcmp(when,"LBIGRAM") == 0||
                strcmp(when,"WDPREVTAG") == 0) 
                {
                strcpy(prev1,split_ptr[3]);
                strcpy(word,split_ptr[4]); 
                } 
            else if (strcmp(when,"RBIGRAM") == 0 ||
                strcmp(when,"WDNEXTTAG") == 0) 
                {
                strcpy(word,split_ptr[3]);
                strcpy(next1,split_ptr[4]); 
                } 
            else if (strcmp(when,"WDAND2BFR")== 0 ||
                strcmp(when,"WDAND2TAGBFR")== 0) 
                {
                strcpy(prev2,split_ptr[3]);
                strcpy(word,split_ptr[4]);
                }
            else if (strcmp(when,"WDAND2AFT")== 0 ||
                strcmp(when,"WDAND2TAGAFT")== 0) 
                {
                strcpy(next2,split_ptr[4]);
                strcpy(word,split_ptr[3]);
                }
            
            for (count = 0; count <= corpus_max_index; ++count) 
                {
                strcpy(curtag, tag_corpus_array[count]);
                if (strcmp(curtag, old) == 0) 
                    {
                    strcpy(curwd,word_corpus_array[count]);
                    sprintf(atempstr2,"%s %s",curwd,neww);
#if RESTRICT_MOVE
                    if (  ! Registry_get(WORDS,curwd) 
                       || Registry_get(SEENTAGGING,atempstr2)
                       ) 
#endif
                        {
                        if (strcmp(when, "SURROUNDTAG") == 0) 
                            {
                            if (count < corpus_max_index && count > 0) 
                                {
                                if (strcmp(lft, tag_corpus_array[count - 1]) == 0 &&
                                    strcmp(rght, tag_corpus_array[count + 1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "NEXTTAG") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (strcmp(tag,tag_corpus_array[count + 1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }  
                        else if (strcmp(when, "CURWD") == 0) 
                            {
                            if (strcmp(word, word_corpus_array[count]) == 0)
                                {
                                change_the_tag(tag_corpus_array, neww, count);
                                }
                            } 
                        else if (strcmp(when, "NEXTWD") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (strcmp(word, word_corpus_array[count + 1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "RBIGRAM") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(next1, word_corpus_array[count+1]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "WDNEXTTAG") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(next1, tag_corpus_array[count+1]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        
                        else if (strcmp(when, "WDAND2AFT") == 0) 
                            {
                            if (count < corpus_max_index - 1) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(next2, word_corpus_array[count+2]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "WDAND2TAGAFT") == 0) 
                            {
                            if (count < corpus_max_index - 1) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(next2, tag_corpus_array[count+2]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        
                        else if (strcmp(when, "NEXT2TAG") == 0) 
                            {
                            if (count < corpus_max_index - 1) 
                                {
                                if (strcmp(tag, tag_corpus_array[count + 2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "NEXT2WD") == 0) 
                            {
                            if (count < corpus_max_index - 1) 
                                {
                                if (strcmp(word, word_corpus_array[count + 2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "NEXTBIGRAM") == 0) 
                            {
                            if (count < corpus_max_index - 1) 
                                {
                                if
                                    (strcmp(next1, tag_corpus_array[count + 1]) == 0 &&
                                    strcmp(next2, tag_corpus_array[count + 2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "NEXT1OR2TAG") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (count < corpus_max_index - 1) 
                                    {
                                    tempcount1 = count+2;
                                    }
                                else 
                                    {
                                    tempcount1 = count+1;
                                    }
                                if
                                    (strcmp(tag, tag_corpus_array[count + 1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }  
                        else if (strcmp(when, "NEXT1OR2WD") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (count < corpus_max_index - 1) 
                                    tempcount1 = count+2;
                                else 
                                    tempcount1 = count+1;
                                if
                                    (strcmp(word, word_corpus_array[count + 1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }   
                        else if (strcmp(when, "NEXT1OR2OR3TAG") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (count < corpus_max_index - 1)
                                    {
                                    tempcount1 = count+2;
                                    }
                                else 
                                    {
                                    tempcount1 = count+1;
                                    }
                                if (count < corpus_max_index - 2)
                                    {
                                    tempcount2 = count+3;
                                    }
                                else 
                                    {
                                    tempcount2 =count+1;
                                    }
                                if (strcmp(tag, tag_corpus_array[count + 1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "NEXT1OR2OR3WD") == 0) 
                            {
                            if (count < corpus_max_index) 
                                {
                                if (count < corpus_max_index -1)
                                    {
                                    tempcount1 = count+2;
                                    }
                                else 
                                    {
                                    tempcount1 = count+1;
                                    }
                                if (count < corpus_max_index - 2)
                                    {
                                    tempcount2 = count+3;
                                    }
                                else 
                                    {
                                    tempcount2 =count+1;
                                    }
                                if (strcmp(word, word_corpus_array[count + 1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }  
                        else if (strcmp(when, "PREVTAG") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (strcmp(tag, tag_corpus_array[count - 1]) == 0) 
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREVWD") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (strcmp(word, word_corpus_array[count - 1]) == 0) 
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "LBIGRAM") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(prev1, word_corpus_array[count-1]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "WDPREVTAG") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(prev1, tag_corpus_array[count-1]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "WDAND2BFR") == 0) 
                            {
                            if (count > 1) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(prev2, word_corpus_array[count-2]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else if (strcmp(when, "WDAND2TAGBFR") == 0) 
                            {
                            if (count > 1) 
                                {
                                if (strcmp(word, word_corpus_array[count]) ==
                                    0 &&
                                    strcmp(prev2, tag_corpus_array[count-2]) ==
                                    0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        
                        else if (strcmp(when, "PREV2TAG") == 0) 
                            {
                            if (count > 1) 
                                {
                                if (strcmp(tag, tag_corpus_array[count - 2]) == 0)
                                    change_the_tag(tag_corpus_array, neww, count);
                                }
                            } 
                        else if (strcmp(when, "PREV2WD") == 0) 
                            {
                            if (count > 1) 
                                {
                                if (strcmp(word, word_corpus_array[count - 2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREV1OR2TAG") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (count > 1) 
                                    {
                                    tempcount1 = count-2;
                                    }
                                else
                                    {
                                    tempcount1 = count-1;
                                    }
                                if (strcmp(tag, tag_corpus_array[count - 1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREV1OR2WD") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (count > 1) 
                                    {
                                    tempcount1 = count-2;
                                    }
                                else
                                    {
                                    tempcount1 = count-1;
                                    }
                                if (strcmp(word, word_corpus_array[count - 1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount1]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREV1OR2OR3TAG") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (count>1) 
                                    {
                                    tempcount1 = count-2;
                                    }
                                else 
                                    {
                                    tempcount1 = count-1;
                                    }
                                if (count >2) 
                                    {
                                    tempcount2 = count-3;
                                    }
                                else 
                                    {
                                    tempcount2 = count-1;
                                    }
                                if (strcmp(tag, tag_corpus_array[count - 1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount1]) == 0 ||
                                    strcmp(tag, tag_corpus_array[tempcount2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREV1OR2OR3WD") == 0) 
                            {
                            if (count > 0) 
                                {
                                if (count>1) 
                                    {
                                    tempcount1 = count-2;
                                    }
                                else 
                                    {
                                    tempcount1 = count-1;
                                    }
                                if (count >2) 
                                    {
                                    tempcount2 = count-3;
                                    }
                                else 
                                    {
                                    tempcount2 = count-1;
                                    }
                                if (strcmp(word, word_corpus_array[count - 1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount1]) == 0 ||
                                    strcmp(word, word_corpus_array[tempcount2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            } 
                        else if (strcmp(when, "PREVBIGRAM") == 0) 
                            {
                            if (count > 1) 
                                {
                                if (strcmp(prev2, tag_corpus_array[count - 1]) == 0 &&
                                    strcmp(prev1, tag_corpus_array[count - 2]) == 0)
                                    {
                                    change_the_tag(tag_corpus_array, neww, count);
                                    }
                                }
                            }
                        else 
                            {
                            fprintf(stderr,
                            "ERROR: %s is not an allowable transform type\n",
                            when);
                            }
                        }
                    }
                }
            free(*split_ptr);
            free(split_ptr);
            DECREMENT
            DECREMENT
            }
        }
    if(Verbose) // Bart 20030224
        {
        /*//Bart 20010425*/ fprintf(stderr,"\n");
        }
    for (count = 0; count <= corpus_max_index; ++count) 
        {
        strcpy(tempstr, tag_corpus_array[count]);
        if (strcmp(tempstr, staart) == 0 &&
            strcmp(tag_corpus_array[count + 1], staart) == 0 &&
            count !=0)
            {
#if STREAM
            fpout << '\n';
#else
            fprintf(fpout,"\n");
#endif
            }
        else if (strcmp(tempstr, staart) != 0) 
            {
#if STREAM
            fpout << word_corpus_array[count] << '/' << tempstr << ' ';
#else
            fprintf(fpout,"%s/%s ", word_corpus_array[count], tempstr);
#endif
            }
        }
#if STREAM
    fpout << '\n' << endl;
#else
    fprintf(fpout,"\n");
#endif
    if(myline) /* Bart 20030415 */
        {
        free(myline); /* Bart 20030415 */
        DECREMENT
        }
    fclose(changefile);
    return 0;  /* Bart 20030415 */
    }
