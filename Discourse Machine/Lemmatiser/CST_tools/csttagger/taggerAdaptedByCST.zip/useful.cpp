#include <string.h>
#include <stdlib.h> // Bart 20001218
#include <stdio.h> // Bart 20030224
#include <ctype.h> // Bart 20030225
#include "useful.h"

/* Set 'product' to the name of the environment variable that contains (part
   of the) path to the options file, not including the file name itself.
   If NULL, a file named 'xoptions' is assumed to be in the current working
   directory. 
   Default value: NULL*/
char * product = NULL;
/* Set 'relative_path_to_xoptions' to the path to the options file, including
   the file name itself and relative to the value stored in the <product>
   environment variable. 
   If NULL, a file named 'xoptions' is assumed to be in the directory
   specified in the <product> environment varaible. (or in the CWD, if 
   product == NULL.
   Default value: NULL */
char * relative_path_to_xoptions = NULL;

int allocated = 0;


char *mystrdup(char *thestr) 
    {
    INCREMENT
    return strcpy((char *)malloc(strlen(thestr)+1),thestr);
    }

int not_just_blank(char *thestr)
/* make sure not just processing a no-character line */
    { 
    char *thestr2;
    thestr2 = thestr;
    while(*thestr2 != '\0') 
        {
        if (*thestr2 != ' ' && *thestr2 != '\t' && *thestr2 != '\n')
            {
            return(1); 
            }
        ++thestr2;
        }
    return(0);
    }

int num_words(char *thestr)
    {
    int count,returncount;
    
    returncount=0;
    count=0;
    while (  thestr[count] != '\0' 
          && (  thestr[count] == ' ' 
             || thestr[count] == '\t'
             )
          ) 
        ++count;
    while (thestr[count++] != '\0') 
        {
        if (thestr[count-1] == ' ' || thestr[count-1] == '\t') 
            {
            ++returncount;
            while (thestr[count] == ' ' || thestr[count] == '\t')
                ++count;
            if (thestr[count] == '\0') 
                --returncount;
            }
        }
    return(returncount);
    }

static char * getBaseDir()
    {
    // loff
    static char basedir[1028];
    char * basedir_ptr;
    // fprintf(stderr,"Initialising, key: %s\n",key);
    if (product && (basedir_ptr = getenv(product /*"QA_DANISH"*/)) != NULL )
        {
        strcpy(basedir,basedir_ptr);
        if(relative_path_to_xoptions)
            strcat(basedir,relative_path_to_xoptions /*"/preprocess/xoptions"*/);
        else
            strcat(basedir,"xoptions");
        // fprintf(stderr,"Initialising using getenv %s\n",basedir);
        }
    else
        strcpy(basedir,"xoptions");
    // loff end
    
    //fprintf(stderr,"Initialising DAQPreprocess, using: %s\n",basedir);
    
    //loff FILE * fp = fopen("xoptions","r");
    return basedir;
    }

long option(char * key) 
    {
    FILE * fp = fopen(getBaseDir(),"r");
    if(fp)
        {
        char line[256];
        while(fgets(line,255,fp))
            {
            if(!strncmp(key,line,strlen(key)))
                {
                char * eqpos = strchr(line,'=');
                if(eqpos)
                    {
                    fclose(fp);
                    return strtol(eqpos+1,NULL,0);
                    }
                else
                    {
                    break;;
                    }
                }
            }
        fclose(fp);
        }
    return -1;
    }

char * coption(char * key) 
    {
    //loff FILE * fp = fopen("xoptions","r");
    FILE * fp = fopen(getBaseDir(),"r");
    if(fp)
        {
        static /*Bart 20030224*/ char line[256];
        while(fgets(line,255,fp))
            {
            if(!strncmp(key,line,strlen(key)))
                {
                char * startp = strchr(line,'=');
                if(startp)
                    {
                    /*FILE * fp = fopen("log.txt","a");*/
                    char * endp;
                    while(isspace(*++startp))
                        ;
                    for(endp = startp;*endp && !isspace(*endp);++endp)
                        ;
                    *endp = '\0';
                    /*if(fp)
                    {
                    fprintf(fp,"%s = \"%s\"\n",key,startp);
                    fclose(fp);
                    }*/
                    fclose(fp);
                    return startp;
                    }
                else
                    break;
                }
            }
        fclose(fp);
        }
    return NULL;
    }

/* ISO8859 *//* NOT DOS compatible! */
/*
const unsigned char lowerEquivalent[256] =
{
      0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
     16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31,
    ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?',
    '@', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '[', '\\', ']', '^', '_',
    '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', 127,
    128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
    144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
    176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
    224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
    240, 241, 242, 243, 244, 245, 246, 215, 248, 249, 250, 251, 252, 253, 254, 223 *//*ringel s*//*,
    224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
    240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255
};
*/
const unsigned char upperEquivalent[256] =
{
      0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
     16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31,
    ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?',

    '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_',
    '`', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '{', '|', '}', '~', 127,

    128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
    144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
    176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,

    192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
    208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223,
    192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207,
    208, 209, 210, 211, 212, 213, 214, 247, 216, 217, 218, 219, 220, 221, 222, 255 /* ij */
};
/*
const bool space[256] =
{
  false, false, false, false, false, false, false, false, false, true,  true,  true,  true,  true,  false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  true,  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
};

const bool alpha[256] =
{
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  
  false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, 
  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, true, 
  false, true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, 
  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  false, false, false, false, false,
  
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false,
  
  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, 
  true,  true,  true,  true,  true,  true,  true,  false, true,  true,  true,  true,  true,  true,  true,  true, 
  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true,  true, 
  true,  true,  true,  true,  true,  true,  true,  false, true,  true,  true,  true,  true,  true,  true,  true, 
};


void AllToLower(char * s)
    {
    while(*s)
        {
        *s = (char)lowerEquivalent[*s & 0xFF];
        ++s;
        }
    }

const char * allToLower(const char * s)
    {
    static char buf[256];
    static char * ret = buf;
    if(ret != buf)
        delete [] ret;
    int l = strlen(s) + 1;
    if(l > 256)
        ret = new char[l];
    else
        ret = buf;
    char * d = ret;
    while(*s)
        {
        *d = (char)lowerEquivalent[*s & 0xFF];
        ++d;
        ++s;
        }
    *d = '\0';
    return ret;
    }


void AllToUpper(char * s)
    {
    while(*s)
        {
        *s = (char)upperEquivalent[*s & 0xFF];
        ++s;
        }
    }

void toLower(char * s)
    {
    *s = (char)lowerEquivalent[*s & 0xFF];
    }

void toUpper(char * s)
    {
    *s = (char)upperEquivalent[*s & 0xFF];
    }
*/
int isUpper(const char * s)
    {
    int S = *s & 0xFF;
    return upperEquivalent[S] == S;
    }
/*
bool isAllUpper(const char * s)
    {
    while(*s)
        {
        int S = *s & 0xFF;
        if(upperEquivalent[S] != S)
            return false;
        ++s;
        }
    return true;
    }

bool isSpace(int s)
    {
    return space[s & 0xFF];
    }

bool isAlpha(int s)
    {
    return alpha[s & 0xFF];
    }
*/
