#ifndef FST_H
#define FST_H

#include "registry.h"
#include "defines.h"
#if STREAM
# include <iostream>
# ifndef __BORLANDC__
using namespace std;
# endif
#else
#include <stdio.h>
#endif

int final_state_tagger(
#if STREAM
                        ostream & fpout,
#else
                        FILE * fpout,
#endif
                       const char * Contextualrulefile,int Corpussize,/*int Linenums,int Tagnums,*/char ** word_corpus_array, char ** tag_corpus_array
#if RESTRICT_MOVE
                       , Registry SEENTAGGING, Registry WORDS
#endif
                       );

#endif
