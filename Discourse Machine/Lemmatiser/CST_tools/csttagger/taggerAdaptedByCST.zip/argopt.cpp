/* argopt.cpp */

#include <string.h>

char *optargCST;
int optindCST = 0;


int getopt(int argc,char *argv[],char *opts)
    {
    static char emptystr[] = "";
    char *index;

    if (!optindCST)    /* argv[0] points to the command verb */
        ++optindCST;
    if (optindCST >= argc)
        {
        optargCST = NULL;
        return -1;
        }

    if ((index = argv[optindCST]) != NULL)
        {
        int optc;
        char * optpos;
        if (*index != '-' && *index != '/')
            {
            /* no option, perhaps something else ? */
            optargCST = NULL;
            return -1;
            }
        if (*(++index) == '-')
            {
            ++optindCST;            /* double --,  end of options */
            optargCST = NULL;
            return -1;
            }
        if (!*index)
            {
                                /* single -, probably not an option */
            optargCST = NULL;
            return -1;
            }
        optc = *index;       /* option letter */
        optpos = strchr(opts,optc);
        if(optpos)
            {
            if(optpos[1] == ':')
                {
                /* this option has always data */
                if(!*++index)
                    {
                    /* try next argument */
                    for (;++optindCST < argc && !*argv[optindCST];);
                    if(  optindCST == argc
                      || argv[optindCST] == NULL
                      ||    *argv[optindCST] == '-'
                         && *(argv[optindCST]+1) != '\0'
                      )
                        {
                        optargCST = emptystr;
                        return optc;  /* no data after all */
                        }
                    else
                        {
                        optargCST = argv[optindCST++]; 
                        return optc;
                        }
                    }
                else
                    {
                    optindCST++;
                    optargCST = index; 
                    return optc;
                    }
                }
            else
                {
                optindCST++;
                optargCST = NULL; 
                return optc;
                }
            }
        else
            {
            optindCST++;
            optargCST = NULL; 
            return -1;
            }
        }
    else
        {
        optindCST++;
        optargCST = NULL;
        return -1;
        }
    }




char *argoptCST(int argc,char *argv[],char *opts,int *argn,char *optc)
    {
    static char emptystr[] = "";
    char *index;
    
    if (!*argn)    /* argv[0] points to the command verb */
        {
        ++(*argn);
        return NULL;
        }
    else if (*argn >= argc)
        {
        return NULL;
        }
    
    if ((index = argv[*argn]) != NULL)
        {
        if (*index != '-' && *index != '/')
            {
            /* no option, perhaps something else ? */
            return NULL;
            }
        if (*(++index) == '-' || !*index)
            {
            ++(*argn);            /* end of options */
            return NULL;
            }
        *optc = *index;       /* option letter */
        if(strchr(opts,*optc))
            {
            /* this option has always data */
            if(!*++index)
                {
                /* try next argument */
                for (;++(*argn) < argc && !*argv[*argn];);
                if(  *argn == argc
                  || argv[*argn] == NULL
                  ||    *argv[*argn] == '-'
                    && *(argv[*argn]+1) != '\0'
                  )
                    {
                    return emptystr;  /* no data after all */
                    }
                else
                    {
                    return (argv[(*argn)++]);
                    }
                }
            else
                {
                (*argn)++;
                return (index);
                }
            }
        else
            {
            (*argn)++;
            return (index);
            }
        }
    else
        {
        (*argn)++;
        return NULL;
        }
    }

