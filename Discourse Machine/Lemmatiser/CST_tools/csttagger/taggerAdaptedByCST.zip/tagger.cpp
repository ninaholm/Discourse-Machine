/* Copyright @ 1993 MIT and University of Pennsylvania */
/* Written by Eric Brill */
/*THIS SOFTWARE IS PROVIDED "AS IS", AND M.I.T. MAKES NO REPRESENTATIONS 
OR WARRANTIES, EXPRESS OR IMPLIED.  By way of example, but not 
limitation, M.I.T. MAKES NO REPRESENTATIONS OR WARRANTIES OF 
MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF 
THE LICENSED SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY 
PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.   */


#include "tagger.h"
#include "registry.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>//Bart 20010108

#include "useful.h"
//#include "log.h"
//LOGCODE
#include "sst.h"
#include "fst.h"
#include "staart.h"
#include "lex.h"
#include "readcorpus.h"



#if STREAM
# include <fstream>
# if defined __BORLANDC__
#  include <strstrea.h>
# else
#  ifdef __GNUG__
#   if __GNUG__ > 2
#    include <sstream>
#   else
#    include <strstream.h>
#   endif
#  else
#   include <sstream>
#  endif
# endif
# ifndef __BORLANDC__
using namespace std;
# endif
#endif


static const char * Lexicon;
//static const char * Corpus;
static const char * Bigrams;
static const char * Lexicalrulefile;
static const char * Contextualrulefile;
static int splitnum;
static char * intermed;
static int START_ONLY_FLAG;
static int FINAL_ONLY_FLAG;
static char * wdlistname; 

static char ** word_corpus_array;
static char ** tag_corpus_array;
static int allocatedcorpussize;
static int corpussize;
static int linenums;
static int tagnums;
static char line[2048];
static char COMMAND[1024];
static int numlines;
static Registry LEXICON_HASH;
static Registry BIGRAM_HASH;
static Registry WORDLIST_HASH;
static Darray RULE_ARRAY;

#if RESTRICT_MOVE
static Registry SEENTAGGING;
static Registry WORDS;
#endif









bool createRegistries
        (
#if RESTRICT_MOVE
        Registry * SEENTAGGING,
        Registry * WORDS,
#endif
        Registry * LEXICON_HASH,
        Registry * BIGRAM_HASH,
        Registry * WORDLIST_HASH,
        const char * Lexicon,
        const char * Lexicalrulefile,
        const char * Bigrams,
        const char * Wordlist,
        int START_ONLY_FLAG,
        Darray * RULE_ARRAY
        )
    {
    int linenums = 0;
    int tagnums = 0;
    FILE * lexicon;
    FILE * rulefile;
    FILE * bigrams;
    FILE * wordlist;
    Registry lexicon_hash;
    Registry good_right_hash;
    Registry good_left_hash;
    Registry bigram_hash;
    Registry wordlist_hash;
    char line[5000];	/* input line buffer */
    char word[MAXWORDLEN];
    char tag[MAXTAGLEN];
    Darray rule_array;
    char * linecopy;
    char **perl_split_ptr;
#if RESTRICT_MOVE
    char ** perl_split_ptr2;
    char * atempstr;
    char space[500];
    /* if in restrict-move mode (described above), */
    /* then we need to read in the lexicon file to see allowable */
    /* taggings for seen words*/
    Registry seentagging;
    Registry words;
#else
    if (! START_ONLY_FLAG) 
#endif
        {
        lexicon = fopen(Lexicon,"r");
        if(!lexicon)
            return false;
        while(fgets(line,sizeof(line),lexicon) != NULL) 
            {
            if (not_just_blank(line)) 
                {
                ++linenums;
                line[strlen(line) - 1] = '\0';
                tagnums += num_words(line);
                }
            }
        fclose(lexicon);
        }

#if RESTRICT_MOVE
    seentagging = *SEENTAGGING = Registry_create(Registry_strcmp,Registry_strhash);
    Registry_size_hint(seentagging,tagnums);

    words = *WORDS = Registry_create(Registry_strcmp,Registry_strhash);
    Registry_size_hint(words,linenums);
#endif

    lexicon_hash = *LEXICON_HASH = Registry_create(Registry_strcmp,Registry_strhash);
    Registry_size_hint(lexicon_hash,tagnums);

    lexicon = fopen(Lexicon, "r");
    if(!lexicon)
        return false;
    while(fgets(line,sizeof(line),lexicon) != NULL)
    /*while(fgets(line,linelen,allowedmovefile) != NULL) */
        {/* Bart 20030415 */
        if (not_just_blank(line)) 
            {
            char *word2;
            char *tag2;
            line[strlen(line) - 1] = '\0';

    /* lexicon hash stores the most likely tag for all known words.
    we can have a separate wordlist and lexicon file because unsupervised
    learning    can add to wordlist, while not adding to lexicon.  For
    example, if a big    untagged corpus is about to be tagged, the wordlist
    can be extended to    include words in that corpus, while the lexicon
    remains static.    Lexicon is file of form: 
    word t1 t2 ... tn 
    where t1 is the most likely tag for the word, and t2...tn are alternate
    tags, in no particular order. */
    /* just need word and most likely tag from lexicon (first tag entry) */
            sscanf(line,"%s%s",word,tag);
            word2 = mystrdup(word);
            tag2 = mystrdup(tag);
            if(!Registry_add(lexicon_hash,(char *)word2,(char *)tag2))
                {
                free(word2);
                free(tag2);
                DECREMENT
                DECREMENT
                }

#if RESTRICT_MOVE
            perl_split_ptr = perl_split(line);
            perl_split_ptr2 = perl_split_ptr;
            ++perl_split_ptr;
            atempstr= mystrdup(*perl_split_ptr2);
            if(!Registry_add(words,atempstr,(char *)1))
                {
                free(atempstr);
                DECREMENT
                }
            while(*perl_split_ptr != NULL) 
                {
                sprintf(space,"%s %s",*perl_split_ptr2,*perl_split_ptr);
                atempstr = mystrdup(space);
                if(!Registry_add(seentagging,atempstr,(char *)1))
                    {
                    free(atempstr);
                    DECREMENT
                    }
                ++perl_split_ptr; 
                }
            free(*perl_split_ptr2);
            free(perl_split_ptr2);
            DECREMENT
            DECREMENT
#endif
            }
        }
    /* read in rule file */
    rule_array = *RULE_ARRAY = Darray_create();
    good_right_hash = Registry_create(Registry_strcmp,Registry_strhash);
    good_left_hash = Registry_create(Registry_strcmp,Registry_strhash);
    
    rulefile = fopen(Lexicalrulefile,"r");
    if(!rulefile)
        return false;
    while(fgets(line,sizeof(line),rulefile) != NULL) 
        {
        if (not_just_blank(line))
            {
            char * tempruleptr;
            line[strlen(line) - 1] = '\0';
//            linecopy = mystrdup(line);
//            Darray_addh(rule_array,linecopy);	   
            perl_split_ptr = perl_split(line);
            Darray_addh(rule_array,perl_split_ptr);	   
            if (strcmp(perl_split_ptr[1],"goodright") == 0) 
                {
                tempruleptr = mystrdup(perl_split_ptr[0]);
                if(!Registry_add(good_right_hash,tempruleptr,(char *)1))
                    {
                    free(tempruleptr);
                    DECREMENT
                    }
                }
            else if (strcmp(perl_split_ptr[2],"fgoodright") == 0) 
                {
                tempruleptr = mystrdup(perl_split_ptr[1]);
                if(!Registry_add(good_right_hash,tempruleptr,(char *)1))
                    {
                    free(tempruleptr);
                    DECREMENT
                    } 
                }
            else if (strcmp(perl_split_ptr[1],"goodleft") == 0) 
                {
                tempruleptr = mystrdup(perl_split_ptr[0]);
                if(!Registry_add(good_left_hash,tempruleptr,(char *)1))
                    {
                    free(tempruleptr);
                    DECREMENT
                    } 
                }
            else if (strcmp(perl_split_ptr[2],"fgoodleft") == 0) 
                {
                tempruleptr = mystrdup(perl_split_ptr[1]);
                if(!Registry_add(good_left_hash,tempruleptr,(char *)1))
                    {
                    free(tempruleptr);
                    DECREMENT
                    }  
                }
//            free(*perl_split_ptr);
//            free(perl_split_ptr);
//            allocated -= 2;
            }
        }
    fclose(rulefile);

    /* read in bigram file */
    bigram_hash = *BIGRAM_HASH = Registry_create(Registry_strcmp,Registry_strhash);
    
    bigrams = fopen(Bigrams,"r");
    if(!bigrams)
        return false;
    while(fgets(line,sizeof(line),bigrams) != NULL) 
        {
        if (strlen(line) > 1) 
            {
            char bigram1[MAXWORDLEN],bigram2[MAXWORDLEN];
            char bigram_space[MAXWORDLEN*2];
            line[strlen(line) - 1] = '\0';
            sscanf(line,"%s%s",bigram1,bigram2);
            if (  Registry_get(good_right_hash,bigram1) 
//Bart 20040203               && Registry_get(ntot_hash,bigram2)
               ) 
                {
                sprintf(bigram_space,"%s %s",bigram1,bigram2);
                linecopy = mystrdup(bigram_space);
                if(!Registry_add(bigram_hash,linecopy,(char *)1))
                    {
                    free(linecopy);
                    DECREMENT
                    } 
                }
            if (  Registry_get(good_left_hash,bigram2) 
//Bart 20040203               && Registry_get(ntot_hash,bigram1)
               ) 
                {
                sprintf(bigram_space,"%s %s",bigram1,bigram2);
                linecopy = mystrdup(bigram_space);
                if(!Registry_add(bigram_hash,linecopy,(char *)1))
                    {
                    free(linecopy);
                    DECREMENT
                    } 
                }
            }
        }
    fclose(bigrams);
    
    freeRegistry(good_right_hash);
    freeRegistry(good_left_hash);

    if (Wordlist) 
        {
        int numwordentries = 0;
        wordlist = fopen(Wordlist,"r");
        if(!wordlist)
            return false;
        while(fgets(line,sizeof(line),wordlist) != NULL) 
            {
            if (not_just_blank(line)) 
                ++numwordentries;
            }
        fclose(wordlist);
        wordlist_hash = *WORDLIST_HASH = Registry_create(Registry_strcmp,Registry_strhash);
        Registry_size_hint(wordlist_hash,numwordentries);
        wordlist = fopen(Wordlist,"r");
        if(!wordlist)
            return false;
        /* read in list of words */
        while(fgets(line,sizeof(line),wordlist) != NULL) 
            {
            if (not_just_blank(line)) 
                {
                char *word2;
                line[strlen(line) - 1] = '\0';
                word2 = mystrdup(line);
                if(!Registry_add(wordlist_hash,(char *)word2,(char *)1)) // Bart 20040203. Notice that the original source code has 'word', not 'word2' on this line. So that must be a bug!
                    {
                    free(word2);
                    DECREMENT
                    } 
                }
            }
        fclose(wordlist);
        }
    return true;
    }

static void deleteRegistries(
#if RESTRICT_MOVE
        Registry SEENTAGGING,
        Registry WORDS,
#endif
        Registry LEXICON_HASH,
        Registry BIGRAM_HASH,
        Registry WORDLIST_HASH
                             )
    {
#if RESTRICT_MOVE
    freeRegistry(SEENTAGGING);
    freeRegistry(WORDS);
#endif
    freeRegistry(LEXICON_HASH);
    freeRegistry(BIGRAM_HASH);
    freeRegistry(WORDLIST_HASH);
    }



static void freeCorpus(char *** word_corpus_array, char *** tag_corpus_array, int corpussize)
    {
    int i;
    char ** w = *word_corpus_array;
    char ** t = *tag_corpus_array;
    for(i = 0;i <= corpussize;++i)
        {
        if(w[i] != staart)
            {
//            LOG("%s/%s",w[i],t[i]);
            free(w[i]);
            free(t[i]);
            DECREMENT
            DECREMENT
            }
        }
    free(w);
    free(t);
    DECREMENT
    DECREMENT
    *word_corpus_array = NULL;
    *tag_corpus_array = NULL;
    }




tagger::tagger()
    {
    Lexicon = NULL;
//    Corpus = NULL;
    Bigrams = NULL;
    Lexicalrulefile = NULL;
    Contextualrulefile = NULL;
    word_corpus_array = NULL;
    tag_corpus_array = NULL;
    allocatedcorpussize = 0;
    corpussize = 0;
    linenums = 0;
    tagnums = 0;
    wdlistname = NULL; 
    intermed = NULL;
#if RESTRICT_MOVE
    SEENTAGGING = NULL;
    WORDS = NULL;
#endif
    LEXICON_HASH = NULL;
    BIGRAM_HASH = NULL;
    WORDLIST_HASH = NULL;
    RULE_ARRAY = NULL;
    }

bool tagger::init(
                const char * _Lexicon,
                const char * _Bigrams,
                const char * _Lexicalrulefile,
                const char * _Contextualrulefile,
                char *_intermed,
                char * _wdlistname,
                int _splitnum,
                int _START_ONLY_FLAG,
                int _FINAL_ONLY_FLAG
                )
    {
    Lexicon = _Lexicon;
    Bigrams = _Bigrams;
    Lexicalrulefile = _Lexicalrulefile;
    Contextualrulefile = _Contextualrulefile;
    splitnum = _splitnum;
    intermed = _intermed;
    START_ONLY_FLAG = _START_ONLY_FLAG;
    FINAL_ONLY_FLAG = _FINAL_ONLY_FLAG;
    wdlistname = _wdlistname;
    if (intermed && splitnum) 
        {
        fprintf(stderr,"Intermediate Files Not Permitted With Split option\n");
        return false;
        }
    if (  (  START_ONLY_FLAG 
          && FINAL_ONLY_FLAG
          ) 
       || (  (  START_ONLY_FLAG 
             || FINAL_ONLY_FLAG
             ) 
          && intermed
          ) 
       || (  FINAL_ONLY_FLAG 
          && wdlistname
          ) 
       || (  START_ONLY_FLAG 
          && splitnum
          )
       ) 
        {
        fprintf(stderr,"This set of options does not make sense.\n");
        return false;
        }
        

    return createRegistries
        (
#if RESTRICT_MOVE
        &SEENTAGGING, 
        &WORDS,
#endif
        &LEXICON_HASH,
        &BIGRAM_HASH,
        &WORDLIST_HASH,
        Lexicon,
        Lexicalrulefile,
        Bigrams,
        wdlistname,
        START_ONLY_FLAG,
        &RULE_ARRAY
        );
    }


#if STREAM
bool tagger::analyse(istream & CORPUS,ostream & fpout)
#else
bool tagger::analyse(FILE * CORPUS,FILE * fpout)
#endif
    {
    FILE *fp/*,*CORPUS*/;

//    Corpus = _Corpus;
    if (! START_ONLY_FLAG) 
        {
//        CORPUS = fopen(Corpus,"r");
        if(!CORPUS)
            return false;
#if STREAM
        while(!CORPUS.eof())
            {
            CORPUS.getline(line,sizeof(line));
            if (not_just_blank(line))
                {
                line[strlen(line) - 1] = '\0';
                allocatedcorpussize += 2;
                allocatedcorpussize += num_words(line) + 1;
                }
            }
        CORPUS.clear();
        CORPUS.seekg(0, ios::beg);
#else
        while(fgets(line,sizeof(line),CORPUS) != NULL) 
            {
            if (not_just_blank(line))
                {
                line[strlen(line) - 1] = '\0';
                allocatedcorpussize += 2;
                allocatedcorpussize += num_words(line) + 1;
                }
            }
        rewind(CORPUS);
#endif
        }
    
    
    if (! splitnum) 
        {
        if (! wdlistname) 
            {
            if (! intermed) 
                { /* -intermed,-split,-wordlist */
                if (START_ONLY_FLAG) 
                    {
/*
                    sprintf(COMMAND,"%s %s %s %s %s",
                    START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile);
*/
                    }
                else if (FINAL_ONLY_FLAG)
                    {
                    corpussize = -1 + readcorpus(
                                                CORPUS,
                                                &word_corpus_array,
                                                &tag_corpus_array,
                                                allocatedcorpussize
                                                );


                    final_state_tagger(fpout,Contextualrulefile,corpussize,word_corpus_array,tag_corpus_array
#if RESTRICT_MOVE
                       , SEENTAGGING, WORDS
#endif
                        );
                    freeCorpus(&word_corpus_array,&tag_corpus_array,corpussize);

                    COMMAND[0] = '\0';

                    /*
                    sprintf(COMMAND,"cat %s | %s %s %s %d %d %d",
                    Corpus,
                    END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
                    */
                    }
                else
                    {
//                    corpussize = start_state_tagger(LEXICON_HASH,Corpus,Bigrams,Lexicalrulefile,NULL /*wordlist*/,allocatedcorpussize,&word_corpus_array,&tag_corpus_array) - 1;
                    corpussize = -1 + start_state_tagger
                                            (
                                            LEXICON_HASH,
                                            BIGRAM_HASH,
                                            WORDLIST_HASH,
                                            CORPUS,
                                            wdlistname,
                                            allocatedcorpussize,
                                            &word_corpus_array,
                                            &tag_corpus_array,
                                            RULE_ARRAY
                                            );
                    final_state_tagger(fpout,Contextualrulefile,corpussize,/*linenums,tagnums,*/word_corpus_array,tag_corpus_array
#if RESTRICT_MOVE
                       , SEENTAGGING, WORDS
#endif
                        );
                    freeCorpus(&word_corpus_array,&tag_corpus_array,corpussize);
                    COMMAND[0] = '\0';
                    /*sprintf(COMMAND,"%s %s %s %s %s | %s %s %s %d %d %d",
                    START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile,
                    END_PROG, Contextualrulefile, Lexicon,corpussize,linenums,tagnums);*/
                    }
                }
            else 
                { /* +intermed  -split -wordlist*/
/*
                sprintf(COMMAND,"%s %s %s %s %s | tee %s |  %s %s %s %d %d %d",
                    START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile,
                    intermed,
                    END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
*/
                }
            }
        else /* - split + wordlist */   
            {
/*
            if (! intermed)  // -intermed 
                {
                if (START_ONLY_FLAG)
                    sprintf(COMMAND,"%s %s %s %s %s %s",
                    START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile, wdlistname);
                else
                    sprintf(COMMAND,"%s %s %s %s %s %s | %s %s %s %d %d %d",
                    START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile, wdlistname,
                    END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
                }
            else  // + intermed 
                sprintf(COMMAND,"%s %s %s %s %s %s | tee %s |  %s %s %s %d %d %d",
                START_PROG, Lexicon, Corpus, Bigrams, Lexicalrulefile,
                wdlistname,
                intermed,
                END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
*/
            }
//        LOG("Tagger A %s",COMMAND);
        /*
        start-state-tagger.exe LEXICON.BROWN ..\temp\sents.txt Bigrams LEXICALRULEFILE.BROWN | final-state-tagger.exe CONTEXTUALRULEFILE.BROWN LEXICON.BROWN 3388 52032 61947
        */
        if(COMMAND[0])
            system(COMMAND);
        }
    else 
        {  /* + split -intermed */
        numlines=0;
//        CORPUS = fopen(Corpus,"r");
        if(!CORPUS)
            return false;
        char tempname1[L_tmpnam];
        tmpnam(tempname1);
        if (! wdlistname) 
            { /* - wordlist */
            if (FINAL_ONLY_FLAG)
                sprintf(COMMAND,"cat %s | %s %s %s %d %d %d",
                tempname1, 
                END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
            else 
                sprintf(COMMAND,"%s %s %s %s %s | %s %s %s %d %d %d",
                START_PROG, Lexicon, tempname1, Bigrams, Lexicalrulefile,
                END_PROG, Contextualrulefile, Lexicon,allocatedcorpussize,linenums,tagnums);
            }
        else 
            { /* + wordlist */
            sprintf(COMMAND,"%s %s %s %s %s %s | %s %s %s %d %d %d",
                START_PROG, Lexicon, tempname1, Bigrams, Lexicalrulefile, wdlistname,
                END_PROG, Contextualrulefile, Lexicon, allocatedcorpussize, linenums, tagnums); 
            }
        fp = fopen(tempname1,"w");
        if(!tempname1)
            return false;

        
#if STREAM
        while(!CORPUS.eof())
            {
            CORPUS.getline(line,sizeof(line));
            if (not_just_blank(line)) 
                {
                ++numlines;
                fputs(line,fp);
                if ((numlines % splitnum) == 0) 
                    {
                    fclose(fp);
//                    LOG("Tagger B %s",COMMAND);
                    system(COMMAND);
                    fp = fopen(tempname1,"w");
                    if(!tempname1)
                        return false;
                    }
                }
            }
//        CORPUS->clear();
//        CORPUS->seekg(0, ios::beg);
#else
        while(fgets(line,sizeof(line),CORPUS) != NULL) 
            {
            if (not_just_blank(line)) 
                {
                ++numlines;
                fputs(line,fp);
                if ((numlines % splitnum) == 0) 
                    {
                    fclose(fp);
//                    LOG("Tagger B %s",COMMAND);
                    system(COMMAND);
                    fp = fopen(tempname1,"w");
                    if(!tempname1)
                        return false;
                    }
                }
            }
//        rewind(CORPUS);
#endif
        
        
/*        
        while(fgets(line,sizeof(line),CORPUS) != NULL) 
            {
            if (not_just_blank(line)) 
                {
                ++numlines;
                fputs(line,fp);
                if ((numlines % splitnum) == 0) 
                    {
                    fclose(fp);
//                    LOG("Tagger B %s",COMMAND);
                    system(COMMAND);
                    fp = fopen(tempname1,"w");
                    if(!tempname1)
                        return false;
                    }
                }
            }
*/
        if ((numlines %splitnum) != 0) 
            {
            fclose(fp);
//            LOG("Tagger C %s",COMMAND);
            system(COMMAND);
            }
        }
    return true;
    }

tagger::~tagger()
    {
    for (unsigned int i = 0;i < Darray_len(RULE_ARRAY);++i) 
        {
        char ** tempstr = (char **)Darray_get(RULE_ARRAY,i);
        free(*tempstr);
        free(tempstr);
        DECREMENT
        DECREMENT
        }
    Darray_destroy(RULE_ARRAY);
    deleteRegistries(
#if RESTRICT_MOVE
        SEENTAGGING,WORDS,
#endif
        LEXICON_HASH,BIGRAM_HASH,WORDLIST_HASH);
//    printf("allocated:%d\n",allocated);
    }



