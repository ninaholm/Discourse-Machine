#ifndef STAART_H
#define STAART_H

extern char staart[];

#endif
