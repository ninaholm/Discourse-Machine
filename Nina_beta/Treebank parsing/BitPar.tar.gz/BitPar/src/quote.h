
/*MA****************************************************************/
/*                                                                 */
/*     File: quote.h                                               */
/*   Author: Helmut Schmid                                         */
/*  Purpose:                                                       */
/*  Created: Mon Feb  3 09:08:27 2003                              */
/* Modified: Mon Feb  3 09:16:44 2003 (schmid)                     */
/*                                                                 */
/*ME****************************************************************/


char *quote( const char *string );
